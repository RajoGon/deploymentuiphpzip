<?php
session_start();
$thispage = 'history';

include('dbconnection.php');

if($_SESSION["connection"]=="disconnected"){
	echo 'no connection';
	//header( 'Location: ./index.php');
}

// Fetching history
$history = " SELECT * FROM dbo.USER_DEPLOYMENT   ORDER BY ID DESC ";
$historystmt = sqlsrv_query( $conn, $history );
if( $historystmt === false) {
    die( print_r( sqlsrv_errors(), true) );
}

$role = $_SESSION['role'];
?>
<!doctype html>
<html class="no-js" lang="">
<?php include('head.php'); ?>
    <body>

<?php 
include('tablecheckbox.php');
include('navbar.php'); 

?>

		<div class="container" >

			<div class="jumbotron">
			  <h1>Deployment Validation.</h1> 
			  <p>Here you can find the details of all the deployments.</p> 
			</div>
			<div id="checkboxes">
				<p id="selectcolumns"> Select the table columns to be displayed</p>
				<div class="form-check form-check-inline">
				  <label class="form-check-label">
				    <input type="checkbox" class="form-check-input" id="srnobox" value="" checked>Sr.no
				  </label>
				</div>
				<div class="form-check form-check-inline">
				  <label class="form-check-label">
				    <input type="checkbox" class="form-check-input" id="patternbox" value="" checked>Dep. Pattern
				  </label>
				</div>
				<div class="form-check form-check-inline">
				  <label class="form-check-label">
				    <input type="checkbox" class="form-check-input" id="tshirtbox" value="" checked>T-shirt Size
				  </label>
				</div>
				<div class="form-check form-check-inline">
				  <label class="form-check-label">
				    <input type="checkbox" class="form-check-input" id="regionbox" value="" checked>Region
				  </label>
				</div>
				<div class="form-check form-check-inline">
				  <label class="form-check-label">
				    <input type="checkbox" class="form-check-input" id="envbox" value="" checked>Env.
				  </label>
				</div>
				<div class="form-check form-check-inline">
				  <label class="form-check-label">
				    <input type="checkbox" class="form-check-input" id="codebox" value="" checked>Engagement Code
				  </label>
				</div>
				<div class="form-check form-check-inline">
				  <label class="form-check-label">
				    <input type="checkbox" class="form-check-input" id="datebox" value="" checked>Date
				  </label>
				</div>
				<div class="form-check form-check-inline">
				  <label class="form-check-label">
				    <input type="checkbox" class="form-check-input" id="usernamebox" value="" checked>Username
				  </label>
				</div>
				<div class="form-check form-check-inline">
				  <label class="form-check-label">
				    <input type="checkbox" class="form-check-input" id="subscriptionbox" value="" checked>Subscription
				  </label>
				</div>
				<div class="form-check form-check-inline">
				  <label class="form-check-label">
				    <input type="checkbox" class="form-check-input" id="statusbox" value="" checked>Status
				  </label>
				</div>
				 <?php 
			        if($role=="admin"){
					echo '<div class="form-check form-check-inline">
				  		<label class="form-check-label">
				   	 	<input type="checkbox" class="form-check-input" id="actionsbox" value="" checked>Actions
				  			</label>
						</div>';
				}
			        ?>
			    </div>
			    <div class="row">
			    	<div class="col-sm-5">
			    		<form method="post" action="printtable.php">
				    	<button type="button"  class="btn btn-primary" onclick="exportexcel()"">Export current view to excel</button>
				    	<button type="submit"  class="btn btn-primary" ">Export to excel</button>
				    	</form>
			    	</div>
				    <div class="col-sm-6">
				    	<form method="post" action="emailhistory.php" id="emailform">
				    	<button type="submit" id="emailexcel1" class="btn btn-primary" ">Email Excel</button>
				    	<input type="text" id="emailaddress" name="email"/>
				    	</form>
				    </div>
				    
				</div>

		</div>
		<div class="space"></div>
		<div id="tablecontainer">
			<table id="historytable" class="table table-dark table-striped table-hover">
			    <thead>
			      <tr>
			        <th class="rowofsr">Sr.no</th>
			        <th class="rowofpattern">Dep. Pattern</th>
			        <th class="rowoftshirt">T-shirt Size</th>
			        <th class="rowofregion">Region</th>
			        <th class="rowofenv">Env.</th>
			        <th class="rowofcode">Engagement Code</th>
			        <th class="rowofdate">Date</th>
			        <th class="rowofusername">Username</th>
			        <th class="rowofsubscription">Subscription</th>
			        <th class="rowofstatus">Status</th>
			        <?php 
			        if($role=="admin"){
			        	echo '<th class="rowofaction">Actions</th>';
			        }
			        ?>
			        

			      </tr>
			    </thead>
			    <tbody>
			      
			      	<?php
			      		
						while( $row = sqlsrv_fetch_array( $historystmt, SQLSRV_FETCH_NUMERIC) ) {
							echo '<tr>';
      						echo '<td class="rowofsr">'.$row[0].'</td>';
      						echo '<td class="rowofpattern">'.$row[1].'</td>';
      						echo '<td class="rowoftshirt">'.$row[2].'</td>';
      						echo '<td class="rowofregion">'.$row[3].'</td>';
      						echo '<td class="rowofenv">'.$row[4].'</td>';
      						echo '<td class="rowofcode">'.$row[5].'</td>';
      						echo '<td class="rowofdate">'.$row[7].'</td>';
      						echo '<td class="rowofusername">'.$row[8].'</td>';
      						echo '<td class="rowofsubscription">'.$row[9].'</td>';
      						echo '<td class="rowofstatus">'.$row[11].'</td>';
      						if($role=="admin"){
      							if($row[11]=="initiated"){
      								echo '<td class="rowofaction">'.'
      							<form method="post" action="updatestatus.php">
		     							 <button type="submit"  class="btn btn-success btn-sm">Approve</button>
		     							<input type="hidden" name="id" value="' .$row[0]. '"/>
		     							<input type="hidden" name="action" value="approved"/>
		    					</form>
		    					<form method="post" action="updatestatus.php">
		     							 <button type="submit" class="btn btn-danger btn-sm">Reject</button>
		     							<input type="hidden" name="id" value="' .$row[0]. '"/>
		     							<input type="hidden" name="action" value="rejected"/>
		    					</form>
		    					<form method="post" action="updatestatus.php">
		     							 <button type="submit" class="btn btn-warning btn-sm">Defer</button>
		     							<input type="hidden" name="id" value="' .$row[0]. '"/>
		     							<input type="hidden" name="action" value="deferred"/>
		    					</form>
      									
      							'.'</td>
			      				</tr>';
      							}else{
      								echo '<td>N/A</td>
			      					</tr>';
      							}
      							
				      		}else{
				      			echo '
			      			</tr>';
	      						
							}
			      		}
						
					?>

			        


			    </tbody>
			  </table>
			  <button type="button"  class="btn btn-primary" onclick="exportexcel()"">Export to Excel</button>

		<div>
    </body>
</html>