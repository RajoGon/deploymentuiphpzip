<?php
session_start();
$showform=0;
$insertedid=0;
if(isset($_SESSION['showform'])) {
    $showform=$_SESSION['showform'];
}else{}
if(isset($_SESSION['insertedid'])) {
    $insertedid=$_SESSION['insertedid'];
}

$thispage = 'index';
include('dbconnection.php');
$user_check = $_SESSION['login_user'];
$role = $_SESSION['role'];

if(!isset($_SESSION['login_user'])){
      header("location:login.php");
   }
//sqlsrv_close( $conn );

// Fetching Region
$region = " SELECT * FROM dbo.REGION_DETAILS ";
$regionstmt = sqlsrv_query( $conn, $region );
if( $regionstmt === false) {
    die( print_r( sqlsrv_errors(), true) );
}
//Patterns
$pattern = " SELECT * FROM dbo.PATTERN_DETAILS ";
$patternstmt = sqlsrv_query( $conn, $pattern );
if( $patternstmt === false) {
    die( print_r( sqlsrv_errors(), true) );
}
//Tshirt
$tshirt = " SELECT * FROM dbo.TSHIRTSIZE_DETAILS ";
$tshirtstmt = sqlsrv_query( $conn, $tshirt );
if( $tshirtstmt === false) {
    die( print_r( sqlsrv_errors(), true) );
}
//Environment
$env = " SELECT * FROM dbo.ENVIRONMENT_DETAILS ";
$envstmt = sqlsrv_query( $conn, $env );
if( $envstmt === false) {
    die( print_r( sqlsrv_errors(), true) );
}
//Resource Names
$resources = " SELECT * FROM dbo.Resources ";
$resourcesstmt = sqlsrv_query( $conn, $resources );
$resourcesstmtforlist = sqlsrv_query( $conn, $resources );
if( $resourcesstmt === false) {
    die( print_r( sqlsrv_errors(), true) );
}

?>

<!doctype html>
<html class="no-js" lang="">
<?php include('head.php'); ?>
    <body>

<?php 
		include('formsubmit.php');
		include('navbar.php');  		
?>
		<div class="container">
			<!-- Jumbo Tron -->
			<div class="jumbotron">
			  <h1>Welcome to KPMG Lighthouse Cloud Deployment</h1> 
			  <p>Here you can submit the deployment by filling in the form bellow</p> 
			</div>		
			<!-- Deployment FORM -->
				<form class="deploymentform" id="depform" method="post" action="submitdeployment.php" <?php if($showform == 1){echo 'hidden';} ?> >
				<div class="row" >

					<div class = "col-sm-4">
			  			<div class="form-group">
						<label for="email">Region</label>
						  <select class="form-control" id="region" name="region1">
						  	<?php
						  		while( $row = sqlsrv_fetch_array( $regionstmt, SQLSRV_FETCH_NUMERIC) ) {
      							echo '<option>'.$row[0].'</option>';
										}
						  	?>
						  </select>
						</div>
					</div>				
				<div class="space"></div>
			
					<div class = "col-sm-4">
			  			<div class="form-group">
						<label for="email">Environment</label>
						  <select class="form-control" id="environment" name="environment1">
						    <?php
						  		while( $row = sqlsrv_fetch_array( $envstmt, SQLSRV_FETCH_NUMERIC) ) {
      							echo '<option>'.$row[0].'</option>';
										}
						  	?>
						  </select>
						</div>

					</div>
					<div class = "col-sm-4">
			  			<div class="form-group">
						  <label for="email">Engagement Code</label>
						  <input  type="number" name="engcode1" class="form-control" id="engcode" min="1000000000" max="999999999999" required>
						</div>
					</div>
				</div>
				<div class="space"></div>
				<div class="checkbox">
				  <label><input type="checkbox" value="" id="checky" required> I agree to the Terms of Service</label>
				</div>
			  <button type="submit" class="btn btn-primary" disabled>Export</button>
			  <button id="deploymentsubmit" type="submit" class="btn btn-primary" disabled="disabled">Submit</button>
			</form>	
			<div class="alert alert-success" id="deploymentadded" <?php if($showform != 1){echo 'hidden';} ?> >
			  <strong>Add resources to the deployment from the form bellow. </strong>
			</div>
			<div class="space"></div>
			
			<!-- Individual resource form -->
			<div id="individualresources" <?php if($showform != 1){echo 'hidden';} ?> >
				<!-- Resource Display form -->
				<div id="resourcelistdisplay">

					<header class="clearfix" id="resourcelistdisplayheader">
						<h4>Resources to be deployed</h4>
						<span class="resourcelistdisplay-counter">3</span>
					</header>
					<div id="resourcelist">
 					<?php
						  		while( $row = sqlsrv_fetch_array( $resourcesstmtforlist, SQLSRV_FETCH_NUMERIC) ) {
							
						   echo' <li id="'.$row[0].'List">'.$row[0].'</li> ';
						    					     
						     }
					?>
					</div> 
				</div>

				
			<div id="addresourcesform">
				<div class="page-header">
				    <h3>Add resources to the deployment</h3>      
				</div>
				<!--test-->
					 <?php
						  		while( $row = sqlsrv_fetch_array( $resourcesstmt, SQLSRV_FETCH_NUMERIC) ) {
      							echo '
      								<form  id="testform">
										<div class="resourcegroup" >
											<div class = "resourcename">
									  			<div class="form-group" >
												  <label><input type="checkbox" name="resourcename" class="resourceselector" value="'.$row[0].'" checked>'.$row[0].'</label>
												</div>
											</div>
											';
											if($row[1]!=''){
												echo'
												<div>
										  			<div class="form-group">
													<label for="email">'.$row[1].'</label>
													 <input type="text" value= "" name="Property1">
													</div>
												</div>';
											}

											if($row[2]!=''){
												echo'
												<div>
										  			<div class="form-group">
													<label for="email">'.$row[2].'</label>
													 <input type="text" value= "" name="Property2">
													</div>
												</div>';
											}
											if($row[3]!=''){
												echo'
												<div>
										  			<div class="form-group">
													<label for="email">'.$row[3].'</label>
													 <input type="text" value= "" name="Property3">
													</div>
												</div>';
											}
											if($row[4]!=''){
												echo'
												<div>
										  			<div class="form-group">
													<label for="email">'.$row[4].'</label>
													 <input type="text" value= "" name="Property4">
													</div>
												</div>';
											}
											echo'
										</div>
										<button type="submit" class="btn btn-primary testbutton" hidden>Submit</button>
									</form>
								<div class="space"></div>

      							';
										}
						  	?>

				<!-- test ends-->

				<button type="button" class="btn btn-primary" id="finishaddingresources">Finish adding resources and deploy</button>
			</div>
		</div>
    	</div>
    </body>
</html>