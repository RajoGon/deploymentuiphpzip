<?php 
		include('dbconnection.php');
		$id=$_POST['id'];
		$status=$_POST['action'];
		echo $id;
		$sql = "Update dbo.USER_DEPLOYMENT set status=(?) where ID=(?) ";
			$params = array($status,$id );

			$stmt = sqlsrv_query( $conn, $sql, $params);
			if( $stmt === false ) {
	     		die( print_r( sqlsrv_errors(), true));
	     		header('Location: ' . $_SERVER['HTTP_REFERER']);
				exit;
			}else{

				header('Location: ' . $_SERVER['HTTP_REFERER']);
				exit;
			}
?>