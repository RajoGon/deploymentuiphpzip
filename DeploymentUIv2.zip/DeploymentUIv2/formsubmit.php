<?php
echo'
<script>
	$(document).ready(function() {


		$(document).click(function() {
		  	var numberofresources = $("input[class=resourceselector]:checked").length
	        $(".resourcelistdisplay-counter").html(numberofresources);
		});



	    $(".resourceselector").click(function(){


	        if ( $(this).is(":checked") ) {
	        	$(this).parent().parent().parent().siblings().css("display","block");
	        	var listid = $(this).val()+"List";
	        	$("#"+listid).show();

		    } 
		    else {
		    	$(this).parent().parent().parent().siblings().css("display","none");
		    	var listid = $(this).val()+"List";
	        	$("#"+listid).hide();


		    }
		    
	    });

	$("#checky").click(function() {
	if ($("#deploymentsubmit").is(":disabled")) {
    	$("#deploymentsubmit").removeAttr("disabled");
    } else {
    	$("#deploymentsubmit").attr("disabled", "disabled");
    }
	});

	$("#resourcelistdisplayheader").click(function() {
		$("#resourcelist").slideToggle(300, "swing");
		$(".resourcelistdisplay-counter").fadeToggle(300, "swing");
	});


	


		$("#deploymentsubmitnul").click(function() {
			var region = $("#region").val();
			var environment = $("#environment").val();
			var engcode = $("#engcode").val();
			var UserName = "';?> <?php echo $_SESSION['login_user']; ?> <?php echo'";
			if (region == "" || environment == "" || engcode == "") {
			alert("Insertion Failed Some Fields are Blank....!!");
			} else {
			// Returns successful data submission message when the entered information is stored in database.
			$.post("submitdeployment.php", {
			region1: region,
			environment1: environment,
			engcode1: engcode,
			username: UserName
			}, function(data) {
			console.log(); 
			alert(data);
			$("#depform")[0].reset();
			});
			}

		});
		
						$("#finishaddingresources").click(function() {
	
				    var empty = $("#individualresources").find("input:visible").filter(function() {

				        return this.value === "";
				    });
				    //alert("empty fields = "+empty);
				    if(!empty.length) {
				        $(".resourceselector:checked").each(function() {
						 	var ResourceName1 = $(this).val();
							var Property11 = 	$(this).parent().parent().parent().parent().find("input[name= '. "'Property1'" .' ]").val();
							var Property22 =  $(this).parent().parent().parent().parent().find("input[name= '. "'Property2'" .' ]").val();
							var Property33 =  $(this).parent().parent().parent().parent().find("input[name= '. "'Property3'" .' ]").val();
							var Property44 =  $(this).parent().parent().parent().parent().find("input[name= '. "'Property4'" .' ]").val();

							if(Property11!="" && Property22!="" &&Property33!="" && Property44!=""){
								$.post("deployresources.php", {
								ResourceName: ResourceName1,
								Property1:Property11,
								Property2:Property22,
								Property3:Property33,
								Property4:Property44
								}, function(data) {
								console.log(data); 
								});
							}else{
								alert("Missing fields");
							}
				        	
				        	
					    });
					    alert("Resources Deployed");
					    window.location.replace("/DeploymentUIv2/aftersubmit.php");
				 }else{
				 	alert("Please fill in the missing fields")
				 }


			 
			});
	});
</script>

';
?>