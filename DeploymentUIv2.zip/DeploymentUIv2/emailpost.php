<?php
echo'
<script>
	$(document).ready(function() {


		$("#emailexcel").click(function() {
		var email1 = $("#emailaddress").val();

		if (email == "") {
		alert("Insertion Failed Some Fields are Blank....!!");
		} else {
		// Returns successful data submission message when the entered information is stored in database.
		$.post("emailhistory.php", {
		email: email1
		}, function(data) {
		alert(data);
		$("#emailform")[0].reset(); // To reset form fields
		});
		}
		});



	});
</script>

';
?>