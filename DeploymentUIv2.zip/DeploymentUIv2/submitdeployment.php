<?php
session_start();
include('dbconnection.php');
$region2=$_POST['region1'];
$environment2=$_POST['environment1'];
$engcode2=$_POST['engcode1'];
$username=$_SESSION['login_user'];
$sql = "INSERT INTO dbo.DUMMY_DEPLOYMENT (Region,Environment,EngagementCode,RequestedDate,UserName,Status) VALUES (?,?,?,?,?,?) SELECT SCOPE_IDENTITY()";
$params = array($region2,$environment2,$engcode2,date(DATE_ATOM),$username,'initiated');
$stmt = sqlsrv_query( $conn, $sql, $params);
if( $stmt === false ) {
     die( print_r( sqlsrv_errors(), true));
}else{
	sqlsrv_next_result($stmt); 
	sqlsrv_fetch($stmt); 

	$_SESSION['insertedid'] = sqlsrv_get_field($stmt, 0);
	$_SESSION['showform']=1;
	session_write_close();
	header("Location: index.php");
	exit();

}
?>