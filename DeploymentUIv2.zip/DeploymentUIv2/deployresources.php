<?php 
session_start();
include('dbconnection.php');
$sql = "INSERT INTO dbo.DUMMY_RESOURCE_DETAILS (ResourceName,Property1,Property2,Property3,Property4,DeploymentID) VALUES (?,?,?,?,?,?)";
$params = array($_POST["ResourceName"],$_POST["Property1"],$_POST["Property2"],$_POST["Property3"],$_POST["Property4"],$_SESSION['insertedid']);

$stmt = sqlsrv_query( $conn, $sql, $params);
if( $stmt === false ) {
     die( print_r( sqlsrv_errors(), true));
}
?>