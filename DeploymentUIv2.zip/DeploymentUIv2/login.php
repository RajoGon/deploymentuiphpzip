<?php
session_start();
$thispage = 'login';
include('dbconnection.php');

   if($_SERVER["REQUEST_METHOD"] == "POST") {

      
      	$email = $_POST["email"]; 
      

		$sql = "SELECT UserName,Role FROM dbo.USERNAME_AUTHORIZATION WHERE UserName = ?";
		$params = array($email);
		$options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
		$stmt = sqlsrv_query( $conn, $sql , $params, $options );
		$row_count = sqlsrv_num_rows( $stmt );      

		
      if($row_count == 1) {

         $_SESSION['login_user'] = $email;
               while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
		      	$_SESSION['role'] = $row["Role"];
				}

         header("location: index.php");
         exit();
      }else {
         $error = "Your Login Name or Password is invalid";
         echo '<script>alert("Your Login Name is invalid");</script>';
      }

   }

?>

<!doctype html>
<html class="no-js" lang="">
<?php include('head.php'); ?>
    <body>

		<div class="container">
			<!-- Jumbo Tron -->
			<div class="jumbotron">
			  <h1>Welcome to KPMG Lighthouse Cloud Deployment</h1> 
			  <p>Please Login to access the portal</p> 
			</div>			
			<!-- FORM -->
			<form class="deploymentform" id="depform" action="" method="post">
				<div class="row">
					<div class = "col-sm-4">

					</div>
					<div class = "col-sm-6">
			  			<div class="form-group">
						  <label for="sel1">Email ID: </label>
						  <input style="width:220px;" type="text" name="email">
						</div>
						<button id="login" type="submit" class="btn btn-primary">Login</button>
					</div>


				</div>

			  
			</form>

    	</div>
    </body>
</html>