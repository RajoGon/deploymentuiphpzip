		
		$("#finishaddingresources").click(function() {

			 $(".resourceselector").is(":checked").each(function() {
	        	$.post("test.php", {
				region1: "hi"
				}, function(data) {
				console.log(); 
				});
		    });
			});


		$("#finishaddingresources").click(function() {	
		    $.post("test.php", {
			region1: "hi"
			}, function(data) {
			console.log(); 
			});

			$.post("test2.php", {
			region1: "hi"
			}, function(data) {
			console.log(); 
			})
			});



			$("#finishaddingresources").click(function() {
	
				    var empty = $("#individualresources").find("input:visible").filter(function() {
				        return this.value === "";
				    });
				    if(!empty.length) {
				        $(".resourceselector:checked").each(function() {
						 	var ResourceName1 = $(this).val();
							var Property11 = 	$(this).parent().parent().parent().parent().find("input[name= '. "'Property1'" .' ]").val();
							var Property22 =  $(this).parent().parent().parent().parent().find("input[name= '. "'Property2'" .' ]").val();
							var Property33 =  $(this).parent().parent().parent().parent().find("input[name= '. "'Property3'" .' ]").val();
							var Property44 =  $(this).parent().parent().parent().parent().find("input[name= '. "'Property4'" .' ]").val();

							if(Property11!="" && Property22!="" &&Property33!="" && Property44!=""){
								$.post("deployresources.php", {
								ResourceName: ResourceName1,
								Property1:Property11,
								Property2:Property22,
								Property3:Property33,
								Property4:Property44
								}, function(data) {
								console.log(); 
								});
							}else{
								alert("Missing fields");
							}
				        	
				        	
					    });
					    window.location.replace("/DeploymentUIv2/aftersubmit.php");
				 }else{
				 	alert("Please fill in the missing fields")
				 }


			 
			});