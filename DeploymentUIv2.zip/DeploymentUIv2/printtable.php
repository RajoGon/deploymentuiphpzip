<?php 
	include('dbconnection.php');
	$filename = "Deployment_history";
	$file_ending = "xls";
	$history = " SELECT ID,Pattern,TShirtSize,Region,Environment,EngagementCode,RequestedDate,UserName,SubscriptionIdUsed,Status FROM dbo.USER_DEPLOYMENT   ORDER BY ID DESC ";
	$historystmt = sqlsrv_query( $conn, $history );
	if( $historystmt === false) {
	    die( print_r( sqlsrv_errors(), true) );
	}
	header("Content-Type: application/xls");    
	header("Content-Disposition: attachment; filename=Deployment_history.xls");  
	header("Pragma: no-cache"); 
	header("Expires: 0");

	
	$columnHeader = '';  
	$columnHeader = "Sr.no" . "\t" . "Dep. Pattern" . "\t" . "T-shirt Size" . "\t". "Region" . "\t". "Environment" . "\t". "Engagement Code" . "\t". "Date" . "\t". "Username" . "\t". "Subscription" . "\t". "Status" . "\t";  
	  
	$setData = '';  
	  
	while ($rec = sqlsrv_fetch_array( $historystmt, SQLSRV_FETCH_NUMERIC)) {  
	    $rowData = '';  
	    foreach ($rec as $value) {  
	        $value = '"' . $value . '"' . "\t";  
	        $rowData .= $value;  
	    }  
	    $setData .= trim($rowData) . "\n";  
	}  
	  
	  

	echo ucwords($columnHeader) . "\n" . $setData . "\n"; 
						
				
?>