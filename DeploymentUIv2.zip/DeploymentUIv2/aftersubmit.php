<?php 
session_start();
$_SESSION['insertedid']="";
$_SESSION['showform']=null;
$showform=0;
$insertedid=0;
header("Location: index.php");
exit();
?>