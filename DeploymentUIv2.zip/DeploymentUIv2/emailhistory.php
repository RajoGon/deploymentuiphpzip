<?php 
	include('dbconnection.php');
	echo'HERE!!!';
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;
	require 'PHPMailer-master/src/PHPMailer.php';
	require 'PHPMailer-master/src/Exception.php';
	require 'PHPMailer-master/src/SMTP.php';
	$email=$_POST['email'];
	$filename = "Deployment_history";
	$file_ending = "xls";
	$history = " SELECT ID,Pattern,TShirtSize,Region,Environment,EngagementCode,RequestedDate,UserName,SubscriptionIdUsed,Status FROM dbo.USER_DEPLOYMENT   ORDER BY ID DESC ";
	$historystmt = sqlsrv_query( $conn, $history );
	if( $historystmt === false) {
	    die( print_r( sqlsrv_errors(), true) );
	}
	
	   
	
	$columnHeader = '';  
	$columnHeader = "Sr.no" . "\t" . "Dep. Pattern" . "\t" . "T-shirt Size" . "\t". "Region" . "\t". "Environment" . "\t". "Engagement Code" . "\t". "Date" . "\t". "Username" . "\t". "Subscription" . "\t". "Status" . "\t";  
	  
	$setData = '';  
	  
	while ($rec = sqlsrv_fetch_array( $historystmt, SQLSRV_FETCH_NUMERIC)) {  
	    $rowData = '';  
	    foreach ($rec as $value) {  
	        $value = '"' . $value . '"' . "\t";  
	        $rowData .= $value;  
	    }  
	    $setData .= trim($rowData) . "\n";  
	}  
	
	file_put_contents('Deployment_history.xls', ucwords($columnHeader) . "\n" . $setData . "\n");
	
	$mail = new PHPMailer(); // create a new object
	$mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
	);
	$mail->IsSMTP(); // enable SMTP
	$mail->SMTPDebug = 0; // debugging: 1 = errors and messages, 2 = messages only
	$mail->SMTPAuth = true; // authentication enabled
	$mail->SMTPSecure = 'tls';
	$mail->Host = 'smtp.gmail.com';
	$mail->Port = 587;
	$mail->IsHTML(true);
	$mail->Username = "cloudsmtp17@gmail.com";
	$mail->Password = "cloudsmtp17!";
	$mail->SetFrom("cloudsmtp17@gmail.com");
	$mail->Subject = "Deployment History";
	$mail->Body = "Hello, please find the attached document containing the deployment history";
	$mail->AddAddress($email);
	$mail->addAttachment('Deployment_history.xls');
	 if(!$mail->Send()) {
	 	echo '("Could not send mail.")';
	 	   
	 } else {
	 	echo '("Mail has been sent")';
	 	
	 }
						
		header('Location: ' . $_SERVER['HTTP_REFERER']);		
?>